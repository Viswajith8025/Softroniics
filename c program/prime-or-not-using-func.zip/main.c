/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void prime();
void main()
{
    prime();
}
void prime(){
    int n,isp=1,D;
    printf("enter a number:");
    scanf("%d",&n);
    if(n<=1){
        isp=0;
        
    }else{
         D=n/2;
        while(D>1){
            if(n%D==0){
                isp=0;
                break;
            }
           D--;
        }
    }
if(isp){
    printf("the entered number is a prime number!");
}else{
        printf("the entered number is not a prime number!");

    
}
    
}







