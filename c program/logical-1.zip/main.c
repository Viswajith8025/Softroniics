/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int main()
{
     char  arr1[100],r;
     int a;
     
    printf("enter the string:");
    scanf("%s",&arr1);
    printf("\nenter the character to be deleted:");
    scanf("%s",&r);
    a=strlen(arr1);
    for(int i=0;i<a;i++)
    {
        if(arr1[i]!=r)
    {
    
    printf("%c",arr1[i]);
    }
    
}
    return 0;
}







