/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int week;
    
    
        
    do{
    printf("enter any number from 1 to 7:");
    scanf("%d",&week);
    switch(week)
    {
        case 1:
        printf("monday\n");
        break;
        
        case 2:
        printf("tuesday\n");
        break;
        
        case 3:
        printf("wednesday\n");
        break;
        
        case 4:
        printf("thursday\n");
        break;
        
        case 5:
        printf("friday\n");
        break;
        
        case 6:
        printf("saturday\n");
        break;
        
        case 7:
        printf("sunday\n");
        break;
        
        default:
        printf("invalid number\n");
    }
    }
         while(week<1 || week>7);
                
    
    
 
    return 0;

}