/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    int i,j,temp;
    int a[8]={3,6,78,52,45,90,76,32};
    for(i=0;i<8;i++){
        for(j=i+1;j<8;j++){
            if(a[j]>a[i]){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
    printf("sorted elements are...\n");
    for(i=0;i<8;i++){
        printf("%d\n",a[i]);
    }

    
}