/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,f,fact;
    
    printf("enter a number:");
    scanf("%d",&a);
    if(a<0)
    printf("error!");
    else{
        for(f=1;f<=a;++f){
            fact *=f;
        }
    }
    
    printf("the factorial of the given number is:%d =%d",a,fact);
    

    return 0;
}
