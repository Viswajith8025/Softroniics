/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,temp,s,k,found;
    int arr1[100];
    printf("enter the size of the array:");
    scanf("%d",&s);
    printf("enter the elements:");
    for(i=0;i<s;i++){
        
    scanf("%d",&arr1[i]);
    }
    
    
    
   for(i=0;i<s;i++){
        for(j=i+1;j<s;j++){
            if(arr1[j]<arr1[i]){
                temp=arr1[i];
                arr1[i]=arr1[j];
                arr1[j]=temp;
            }
            
        }
    }
    printf("enter the element to be searched:");
    scanf("%d",&k);
    for (i=0;i<s;i++) {
        if (arr1[i] == k) {
            found = 1;
            break;
        }
    }

    if (found) {
    printf("the given number is in the array");
   } else{
      printf("the given number is not in the array");
   }
    
   
    return 0;
}

