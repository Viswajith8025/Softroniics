/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main()
{
    char ch[100],ch2[100],ch3[100];
    printf("enter a string:");
    gets(ch);
    printf("the length of the given string is %d" ,strlen(ch));
    
    printf("\nenter the second string:");
    gets(ch2);
    if(strcmp(ch,ch2)==0){
    printf("strings are equal!");}
    else{
    printf("strings are not equal!");}
    
    printf("\nenter another string:");
    gets(ch3);
    strcat(ch,ch3);
    printf("\n new string is:%s",ch);


    printf("\n lower case of string is:%s",strlwr(ch));
    printf("\n upper case of string is:%s",strupr(ch));
    return 0;
}
