/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int isp (int num) {
    if (num <= 1) return 0;
    if (num == 2) return 1;
    if (num % 2 == 0) return 0;
    for (int i = 3; i * i <= num; i += 2) {
        if (num % i == 0) return 0;
    }
    return 1;
}
int main()
{
    int a,b,i;
    printf("enter first range:");
    scanf("%d",&a);
    printf("enter second range:");
    scanf("%d",&b);
    
     printf("Prime numbers between %d and %d are:\n",a,b);
    for(i=a;i<=b;i++){
    if(isp(i)){
        printf("%d\n",i);
    }
    }
    

    return 0;
}