/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


void product();
void main()

{
    printf("product of the given numbers ");
    product();
}
    void product()

 { 
 int a,b; 
 printf("\nEnter first number:"); 
 scanf("%d",&a);
 printf("\nEnter second number:"); 
 scanf("%d",&b);
printf("The product is %d",a*b);

}