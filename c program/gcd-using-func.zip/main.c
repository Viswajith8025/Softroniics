/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void gcd();
void main()
{
   gcd();
}
void gcd(){
    int a,b;
    int n1,n2;
    printf("enter two numbers:");
    scanf("%d %d",&n1,&n2);
        if(b==0){
            return a;
        }else{
            return gcd(b,a%b);
        }
}
    
   int result = gcd(n1, n2);
        printf("The GCD of %d and %d is: %d\n", n1, n2, result);
    } 
}

   
