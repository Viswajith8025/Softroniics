/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,temp;
    char str[100];
    printf("enter a string :");
    scanf("%s",str);
    for(i=0;str[i]!='\0';i++);
        for(j=0;j<i/2;j++){
            temp=str[j];
            str[j]=str[i-j-1];
            str[i-j-1]=temp;
        }
        printf("the reversed string is :%s",str);

    return 0;
}
