/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    printf("enter temp in centigrade:");
    scanf("%d",&a);
    if(a<0){
        printf("freezing weather\n");
       } else if(a>=0&&a<=10){
        printf("very cold weather\n");
        }else if(a>10&&a<=20){
        printf("cold weather\n");
        }else if(a>20&&a<=30){
        printf("normal weather\n");
        }else if(a>30&&a<=40){
        printf("hot weather\n");
        }else {
        printf("hot weather\n");
    }

    return 0;
}