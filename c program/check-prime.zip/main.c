/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num,isp=1;
    
    printf("enter a number:");
    scanf("%d",&num);
    
    if(num<=1){
        isp=0;
        
    }else{
        int D=num/2;
        while(D>1){
            if(num%D==0){
                isp=0;
                break;
            }
           D--;
        }
    }
if(isp){
    printf("the entered number is a prime number!");
}else{
        printf("the entered number is not a prime number!");

    
}
    return 0;
}