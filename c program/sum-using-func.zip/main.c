/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void sum();
void main()
{
    printf("the sum of n natural numbers\n");
    sum();
}
void sum(){
    int n,i,r=0;
    
    printf("enter a range:");
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        r+=i;
    }
    printf("the sum of n natural numbers is :%d",r);

    return 0;
}
