/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,s,j;
    
    printf("enter the size of the array :");
    scanf("%d",&s);
    int arr[s];
    printf("enter the elements of the array :");
    for(i=0;i<s;i++){
    scanf("%d",&arr[i]);
    }
    int evenS=0;
    for(i=0;i<s;i++){
        if(arr[i]%2==0){
            evenS++;
        }
    }
    int Earr[evenS];
    j=0;
    for(i=0;i<s;i++){
        if(arr[i]%2==0){
            Earr[j++]=arr[i];
        }
    }
    for(i=0;i<evenS;i++){
        printf("%d",Earr[i]);
    }
    return 0;
}