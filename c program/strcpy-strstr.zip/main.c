/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main()
{
    char ch[100],ch2[100];
    printf("enter a string:");
    gets(ch);
    strcpy(ch2,ch);
     char*sub;
    sub=strstr(ch2,"viswajith");
    printf("value of second string is:%s",sub);
   

    return 0;
}