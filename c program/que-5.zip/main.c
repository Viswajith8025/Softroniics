/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int main()
{
     char  arr1[100],c;
     int a,j=0;
     
    printf("enter the string:");
    scanf("%s",&arr1);
    printf("\nenter the character to be counted:");
    scanf("%s",&c);
    a=strlen(arr1);
    for(int i=0;i<a;i++)
    {
        if(arr1[i]==c){
   j++;
        }
    }
    
    printf("the number of occurunces :%d",j);
    
    

    return 0;
}



