/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("enter first number:");
    scanf("%d",&a);
    printf("enter second number:");
    scanf("%d",&b);
    printf("enter third number:");
    scanf("%d",&c);
    
    if (a>b&a>c)
        
    printf("first number is the greatest:%d",a);
    
    if (b>a&b>c)
        
    printf("second number is the greatest:%d",b);
    
    if (c>b&c>a)
        
    printf("third number is the greatest:%d",c);
    
    return 0;
}