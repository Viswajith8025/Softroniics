/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number;
    printf("Enter a number");
    scanf("%d",&number);
    if(isprime(&number)){
    printf("the given number is a prime number");
   } else{
    printf("the given number is not a prime number");
}
    return 0;
}
