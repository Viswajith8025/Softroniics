/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int rows,i,j,S;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    
    for(i=rows;i>=1;i--){
        for(S=0;S<=rows-i;S++){
            printf(" ");
        }
        for(j=1;j<=2*i-1;j++){
            printf("-");
        }
        printf("\n");
    }


    return 0;
}