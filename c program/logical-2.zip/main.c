/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int main()
{
     int  arr[100],arr2[100];
     int i,j,k,s;
     printf("enter the size of the array:");
     scanf("%d",&s);
     printf("enter the elemnts:");
     for(i=0;i<=s;i++)
         {
              
              scanf("%d",&arr[i]);
    }

     j=0;
    for(i=0;i<=s;i=i+2)
    {
        arr2[j]=arr[i];
        j++;
    }
    printf("the elements after removing odd indices:");
    for(k=0;k<j;k++){
         printf("%d",arr2[k]);
    }

    return 0;
}