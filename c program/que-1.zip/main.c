/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,s,temp,arr[100];
    printf("enter the size of the array:");
    scanf("%d",&s);
    printf("\nenter the elements of the array:");
    for(i=0;i<s;i++){
        scanf("%d",&arr[i]);
    }
    
    
   for(i=0;i<s;i++){
        for(j=i+1;j<s;j++){
            if(arr[j]<arr[i]){
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
            
        }
    }
    printf("sorted array:");
    for(i=0;i<s;i++){
        printf("%d ",arr[i]);
    }
    printf("\n");

    return 0;
}


 