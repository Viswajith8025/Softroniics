/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>

int main()
{
    double A,P,r,t;
    int n;
    printf("enter the initial principal balance:");
    scanf("%lf",&P);
        printf("enter the annual intrest rate:");
        scanf("%lf",&r);
            printf("enter the time in years:");
            scanf("%lf",&t);
             printf("enter the number of times intrest applied per period:");
            scanf("%d",&n);
            
           int R=r/100;
           int base=1+(r/n);
           int exponent=n*t;
           A=P*pow(base,exponent);
            
            printf("compound intrest is :%lf\n",A);
            
    return 0;
}
