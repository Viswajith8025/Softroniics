/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    char c;
    int a,b;

    // Prompt user to enter an operator
    printf("Enter an operator (+, -, *, /): ");
    scanf("%c", &c);

    // Prompt user to enter two operands
    printf("Enter two operands: ");
    scanf("%d %d", &a, &b);

    // Perform the calculation based on the operator
    switch (c) {
        case '+':
            printf("%d + %d = %d\n", a, b, a + b);
            break;
        case '-':
            printf("%d - %d = %d\n", a, b, a - b);
            break;
        case '*':
            printf("%d * %d = %d\n", a, b, a * b);
            break;
        case '/':
            if (b != 0)
                printf("%df / %df = %d\n", a, b, a / b);
            else
                printf("Error! Division by zero is not allowed.\n");
            break;
        default:
            printf("Error! Operator is not correct.\n");
    }

    return 0;
}